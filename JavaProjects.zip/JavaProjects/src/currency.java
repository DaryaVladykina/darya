    public class currency {
        int rupee = 63;
        int dirham = 3; // UAE
        int real = 3;  // brazilian
        int chilean_peso = 595;
        int mexican_peso = 18;
        int _yen = 107;
        int $australian = 2;  // australian dollar
        static int dollar;
        int Rupee = 63;

        static public void SetDollar(int d)
        {
            dollar=d;

        }

        public void printCurrencies() {

            {
                int i=5;
            }

            int i=5;

            System.out.println("rupee: " + rupee);
            System.out.println("dirham: " + dirham);
            System.out.println("real: " + real);
            System.out.println("chilean_peso: " + chilean_peso);
            System.out.println("mexican_peso: " + mexican_peso);
            System.out.println("$australian: " + $australian);
            System.out.println("dollar: " + dollar);
            System.out.println("Rupee: " + Rupee);

        }

        static public currency getIt()
        {

            currency necc = new currency();

            return necc;
        }
        static void arrays () {
            System.out.println("\nInside arrays ...");
        int [] myArray = new int[]{9,11,2,5,4,4,6};
        System.out.println("myArray.length " + myArray.length);
        System.out.println("myArray[5] " + myArray[5]);
        System.out.println("myArray[9] " + myArray[9]);
        }

        public static void main(String[] args) {
            double avg1 = (2+3)/2;
            double avg2 = (double)(2+3)/2;
            //System.out.println(avg1);
            //System.out.println(avg2);
            //currency cc = getIt();
            //cc.printCurrencies();
            //cc.SetDollar(500);
            //cc.printCurrencies();
            arrays ();
        }
    }



