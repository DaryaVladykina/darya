public class Student {
    int id;
    String name;
    String gender = "female";

    Student (int id, String name){
        this.name = name;
        this.id = id;

    }

    Student (int id, String name, String gender){
        this.id = id;
        this.name = name;
        this.gender = gender;
    }
    boolean UpdateProfile (String name){
        return true;
    }
}
