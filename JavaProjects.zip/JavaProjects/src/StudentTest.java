public class StudentTest {
    public static void main (String [] args){
        int [] studentIds = new int [] {1001,1002,1003};
        Student student1 = new Student(studentIds [0], "Pavel", "male");
        Student student2 = new Student(studentIds [1], "Pavel" );
        Student student3 = new Student(studentIds [2], "Paulina", "female");
        System.out.println("name:" + student1.name + " " + student1.gender + " " + student1.id);
        System.out.println("gender:" + student1.gender);
        System.out.println("name:" + student3.name);
    }
}
