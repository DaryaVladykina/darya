public class CurrencyConverter {

    double[] exchangeRates = new double[]{63.0, 3.0, 3.0, 595.5, 18.0, 107.0, 2.0};

    void setExchangeRates(double[] rates) {
        exchangeRates = rates;
    }

    void updateExchangeRate(int countryIndex, double newVal) {
        exchangeRates[countryIndex] = newVal;
    }

    double getExchangeRate(int countryIndex) {
        return exchangeRates[countryIndex];
    }

    void printCurrencies() {

        System.out.println("rupee: " + exchangeRates[0]);
        System.out.println("dirham: " + exchangeRates[exchangeRates.length - 6]);
        System.out.println("real: " + exchangeRates[exchangeRates.length - 5]);
        System.out.println("chilean_peso: " + exchangeRates[exchangeRates.length - 4]);
        System.out.println("mexican_peso " + exchangeRates[exchangeRates.length - 3]);
        System.out.println("_yen: " + exchangeRates[exchangeRates.length - 2]);
        System.out.println("$australian: " + exchangeRates[exchangeRates.length - 1]);
        System.out.println("exchangeRates.length " + exchangeRates.length);
    }

    public static void main(String[] args) {
        CurrencyConverter cc = new CurrencyConverter();
    }
}



