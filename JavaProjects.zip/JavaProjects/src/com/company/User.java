package com.company;

class User {
    int id;
    String name;
    int salary;

    User(int UserId, String Username) {
        id = UserId ;
        name = Username;
    }

    User(int userId, String userName, int userSalary) {
        this(userId, userName);
        salary = userSalary;


    }

    public static void main(String[] args) {
        User instructor = new User(1002, "Dheeru", 50000);
        System.out.println("Name: " + instructor.name);
    }
}