public class MoneyTransferService {
    double[] exchangeRates;
CurrencyConverter cc =  new CurrencyConverter();

    public MoneyTransferService() {
    }

    public MoneyTransferService(double[] exchangeRates) {
        this.exchangeRates = exchangeRates;
    }


    double computeTransferAmount(int countryIndex, double amount) {
        return amount * cc.getExchangeRate(countryIndex);
    }

    double computeTransferFee(int countryIndex, double amount) {
        return 0.02 * cc.getExchangeRate(countryIndex);
    }

    static void varargsOverload(boolean b, int k, int j, int i) {
        System.out.println("/nInside varargsOverload with varargs...");
    }
    static void varargsOverload(boolean b, int...list){
        System.out.println("/nInside varargsOverload with varargs...");
        System.out.println("list.length:" + list.length);
    }
    public static void main(String[] args) {

        MoneyTransferService transferService = new MoneyTransferService();


        double transferAmount = transferService.computeTransferAmount(0, 1000);

        double transferFee = transferService.computeTransferFee(0, 1000);

        System.out.println("Transfer Amount: " + transferAmount);

        System.out.println("Transfer Fee: " + transferFee);

        varargsOverload(true, 1,2,3);
        varargsOverload(false, 1,2,3,4,5,6,7,8);
        varargsOverload(true);

        MoneyTransferService moneyTransferService = new MoneyTransferService();

        }

    }

