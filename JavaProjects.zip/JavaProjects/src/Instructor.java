public class Instructor {
    long id;
    String name;
    String title;
    String department;
    Book[] books;

    public Instructor() {
    }

    Instructor(long id, String name, String title, String department, Book[] books) {
        this(id, name, title, department);
        this.books = books;
    }

    Instructor(long id, String name, String title, String department) {
        this(id, name, title);
        this.department = department;
    }

    Instructor(long id, String name, String title) {
        this(id, name);
        this.title = title;
    }


    Instructor(long id, String name) {
        this.id = id;
        this.name = name;
    }

    public String getMostRecentBookTitle() {
        return books [books.length-1].title;  }

    public Book updateBook(int index, String title) {
     //   Book OldBook = new Book ();
     //   OldBook.title = books [index].title;

        Book OldBook = new Book(books[index]);

        books [index].title = title;
        return OldBook;
    }

    public Book updateBook(int index, Book book) {
        Book OldBook = new Book(books [index].title);
        books [index] = book;
        return OldBook;
    }

    public static void main(String[] args) {
        Book book1 = new Book("Java for Beginners");
        Book book2 = new Book("Scala for Beginners");
        Book book3 = new Book("Effective Python");
        Instructor instructor = new Instructor(101, "John", "Assistant Professor", "Computer Science", new Book[]{book1, book2, book3});

    Book z = instructor.updateBook(2, "dasha prelest");
    Book y = instructor.updateBook(1, new Book("Misha"));





    }

}